package root.gcd;

import org.junit.jupiter.api.Test;

import static java.time.Duration.ofMillis;
import static org.junit.jupiter.api.Assertions.*;

class GCDTest {
    GCD gcd = new GCD();

    /***
     * Тест на положительные значения аргументов.
     * Как можно видеть, все нормально.
     */
    @Test
    void positiveGCD() {
        assertEquals(1, gcd.gcd(10, 31));
        assertEquals(5, gcd.gcd(100, 15));
    }

    /***
     * Тест на отрицательные значения первого, второго, обоих аргументов.
     * Тоже все работает нормально.
     */
    @Test
    void negativeGCD() {
        assertEquals(1, gcd.gcd(-45, 13));
        assertEquals(15, gcd.gcd(-45, 30));
        assertEquals(15, gcd.gcd(45, -30));
        assertEquals(15, gcd.gcd(-45, -30));
    }

    /***
     * Тест на нулевое значение первого, второго, обоих аргументов
     * в сочетании с отрицательными и положительными значениями
     * другого аргумента.
     * Все работает корректно.
     */
    @Test
    void zeroGCD() {
        assertEquals(0, gcd.gcd(0, 0));
        assertEquals(30, gcd.gcd(0, 30));
        assertEquals(30, gcd.gcd(0, -30));
        assertEquals(45, gcd.gcd(45, 0));
        assertEquals(45, gcd.gcd(-45, 0));
    }

    /***
     * Тест на взаимнопростые аргументы - наибольший общий делитель
     * равен единице, как и требуется.
     */
    @Test
    void coprimeGCD() {
        assertEquals(1, gcd.gcd(71, 92));
        assertEquals(1, gcd.gcd(17, 35));
        assertEquals(1, gcd.gcd(3, 1000));
    }

    /***
     * Тест на равные аргументы, положительные и отрицательные.
     * Как и требуется по условию, результат равен их модулю.
     */
    @Test
    void equalGCD() {
        assertEquals(18, gcd.gcd(18, 18));
        assertEquals(18, gcd.gcd(-18, -18));
    }

    /***
     * Тест на аргументы, один из которых делит другой.
     */
    @Test
    void dividerGCD() {
        assertEquals(18, gcd.gcd(18, 36));
        assertEquals(18, gcd.gcd(72, 18));
        assertEquals(18, gcd.gcd(-72, 18));
        assertEquals(18, gcd.gcd(72, -18));
    }

    /***
     * Тест на наибольший общий делитель в обычном случае.
     */
    @Test
    void commonGCD() {
        assertEquals(17, gcd.gcd(85, 102));
        assertEquals(17, gcd.gcd(0, -17));
        assertEquals(9, gcd.gcd(1368, 459));
        assertEquals(3, gcd.gcd(51, 300));
    }

    /***
     * Тест на граничные значения входных аргументов.
     * В ситуациях, когда аргументы либо не равны Integer.MIN_VALUE,
     * функция работает корректно.
     */
    @Test
    void borderlineGCD() {
        int min = Integer.MIN_VALUE;
        int max = Integer.MAX_VALUE;
        assertEquals(max, gcd.gcd(max, max));
        assertEquals(1, gcd.gcd(13, max));
        assertEquals(1, gcd.gcd(max, 4));
        assertEquals(min, gcd.gcd(min, min));
    }

    /***
     * Тест на граничные значения входных аргументов, конкретно Integer.MIN_VALUE.
     * В ситуации, когда оба аргумента равны Integer.MIN_VALUE,
     * функция возвращает его, что нарушает требование 1: результат не должен быть
     * отрицательным.
     * Следовательно тест на соответствие требованию 1 не проходится.
     */
    @Test
    void borderlineNegativeFailureGCD() {
        int min = Integer.MIN_VALUE;
        assertTrue(gcd.gcd(min, min) >= 0);
    }

    /***
     * Не работающий тест на границы аргументов.
     * При одном из аргументов равном Integer.MIN_VALUE (кроме случая,
     * когда они оба равны Integer.MIN_VALUE) функция не вычисляется
     * за отведенное ей время - и тест не проходится.
     * Наверное это можно считать ошибкой, хотя в требованиях
     * не было указано четкого времени, за которое программа
     * должна завершать работу.
     */
    @Test
    void borderlineFailureGCD() {
        int min = Integer.MIN_VALUE;
        int max = Integer.MAX_VALUE;
        assertTimeoutPreemptively(ofMillis(100), () -> {
            assertEquals(1, gcd.gcd(max, min));
            assertEquals(1, gcd.gcd(min, max));
            assertEquals(1, gcd.gcd(min, 3));
            assertEquals(16, gcd.gcd(-16, min));
        });
    }

    /***
     * Тест на соседние числа Фибоначчи - вроде бы производительность в порядке.
     */
    @Test
    void fibonacciGCD() {
            assertEquals(1, gcd.gcd(433494437, 701408733 ));
    }
}